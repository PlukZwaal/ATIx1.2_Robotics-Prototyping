using Avans.StatisticalRobot;

public class RobotController
{
    private bool _laatRobotRijden;
    private CancellationTokenSource _cancellationTokenSource;
    private Task _robotTask;
    Ultrasonic ultrasonicSensor = new Ultrasonic(18);

    public RobotController()
    {
        _laatRobotRijden = false;
    }

    public void StartRobot()
    {
        _cancellationTokenSource = new CancellationTokenSource();
        _laatRobotRijden = true;
        _robotTask = MoveRobotAsync(_cancellationTokenSource.Token);
    }

    public void StopRobot()
    {
        _laatRobotRijden = false;
        _cancellationTokenSource?.Cancel();
        Robot.Motors(0, 0);
        Console.WriteLine("Robot is gestopt.");
    }

    public void ForwardRobot()
    {
        Robot.Motors(100, 100);
    }


    public void BackwardRobot()
    {
        Robot.Motors(-100, -100);
    }

    public void LeftRobot()
    {
        Robot.Motors(-50, 0);
        Robot.Wait(1000);
    }

    public void RightRobot()
    {
        Robot.Motors(0, -50);
        Robot.Wait(1000);
    }

    private async Task MoveRobotAsync(CancellationToken cancellationToken)
    {
        while (_laatRobotRijden && !cancellationToken.IsCancellationRequested)
        {
            int distance = ultrasonicSensor.GetUltrasoneDistance();
            if (distance < 10)
            {
                Robot.Motors(-75, -75);
                Robot.Wait(1000);
                Robot.Motors(75, 0);
            }
            else if (distance < 30)
            {
                Robot.Motors(75, 0);
            }
            else
            {
                Robot.Motors(75, 75);
            }
            await Task.Delay(500);
        }
    }
}