using SimpleMqtt;
using System;
using System.Threading;
using System.Threading.Tasks;

public class MqttClientHandler
{
    private SimpleMqtt.SimpleMqttClient _client;

    public MqttClientHandler()
    {
        _client = SimpleMqtt.SimpleMqttClient.CreateSimpleMqttClientForHiveMQ("robotnative");
    }

    public async Task StartListeningAsync(RobotController robotController)
    {
        await _client.SubscribeToTopic("robot");

        _client.OnMessageReceived += (sender, eventArgs) =>
        {
            string message = eventArgs.Message;

            switch (message)
            {
                case "ping":
                    _client.PublishMessage("pong", "robot");
                    break;

                case "emergencystop":
                    robotController.StopRobot();
                    Environment.Exit(0); 
                    break;
                case "stoprobot":
                    robotController.StopRobot();
                    break;

                case "startrobotautowalk":
                    robotController.StartRobot();
                    break;

                case "forward":
                    robotController.ForwardRobot();
                    break;

                case "backward":
                    robotController.BackwardRobot();
                    break;

                case "left":
                    robotController.LeftRobot();
                    break;

                case "right":
                    robotController.RightRobot();
                    break;

                default:
                    Console.WriteLine($"Onbekend bericht ontvangen: {message}");
                    break;
            }
        };

        while (true)
        {
            Thread.Sleep(500);
        }
    }
}
