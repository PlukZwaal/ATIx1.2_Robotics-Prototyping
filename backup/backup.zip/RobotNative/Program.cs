

using Avans.StatisticalRobot;

using System;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        var ultrasonicSensor = new Ultrasonic(18);
        var dht12Sensor = new DHT12(24);
        var lightSensor = new LightSensor(4, 100);
        var motorController = new MotorController();
        var sensorManager = new SensorManager(ultrasonicSensor, dht12Sensor, lightSensor, motorController);
        var robotController = new RobotController(sensorManager, motorController);
        var mqttClientHandler = new MqttClientHandler();
        var dataCollector = new DataCollector(sensorManager, mqttClientHandler);
        var cancellationTokenSource = new CancellationTokenSource();
        dataCollector.StartCollecting(cancellationTokenSource.Token);

        await mqttClientHandler.StartListeningAsync(robotController);
    }
}

