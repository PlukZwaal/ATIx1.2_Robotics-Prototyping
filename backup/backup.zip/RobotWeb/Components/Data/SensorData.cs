public class SensorData
{
    public int Id { get; set; }
    public double Temperature { get; set; }
    public double Humidity { get; set; }
    public int Battery { get; set; }
    public int Lux { get; set; }
    public string Timestamp { get; set; }
}